let indicacao = ['Video1', 'Video2', 'Video3', 'Video4']
let remocoes = 0
 function removeVideo(){
    indicacao.pop()
    remocoes++
    if(remocoes === 3){
        indicacao.push('VideoNovo')
        remocoes = 0
   }
    console.log('Recomendações ', indicacao)
}

removeVideo()
removeVideo()
removeVideo()
