let cliente = ['Amanda', 'Alessandra', 'Alana']
    let first = cliente.unshift('Marta')
    cliente.pop()
    console.log(cliente)