let alunos = ['Melissa', 'Gabriela', 'Sophie', 'Anne']
let pos = alunos.indexOf('Sophie')
alunos.splice(pos,1,'Cleberson')
console.log(alunos)