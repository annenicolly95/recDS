let Espera = ['Player1', 'Player2']
function novaPartida(NovoJogador){
    if (Espera.length < 3) {
        Espera.unshift('NovoJogador')
    }else{
        Espera.shift()
    }
    console.log(Espera)
}
novaPartida('Player3')
novaPartida('Player4')
novaPartida('Player5')
novaPartida('Player6')