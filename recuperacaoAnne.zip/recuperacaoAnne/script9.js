let estudantes = ["Cleiton", "Marielson", "Clebertinelson", "Antonela"]
let maior10 = estudantes.find(num => num.length > 10)
console.log(maior10)