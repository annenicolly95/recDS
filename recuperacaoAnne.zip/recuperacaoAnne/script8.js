let livros = ["O morro", "Crepúsculo", "A sala", "Joao e Maria"]
let catalogo = livros.indexOf("A sala")
console.log(catalogo)
console.log(livros.indexOf("Diário de Anne Frank"))