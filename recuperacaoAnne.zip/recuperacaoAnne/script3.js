let peca = ['Velas', 'Correia', 'Coxim']
    let first = peca.unshift('Radiador')
    peca.pop()
    console.log(peca)