let carrinho = ['Macarrao', 'Tomate', 'Milho']
function addProduto(produto){
    carrinho.push(produto)
    console.log(carrinho)
}
function Removeproduto(produto){
    carrinho.pop(produto)
    console.log(carrinho)
}

addProduto('Ervilha')
Removeproduto ()