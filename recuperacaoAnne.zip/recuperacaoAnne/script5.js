let eventos = ['5:00 - Acordar', '5:30- Tomar banho', '11:00 - Jogar videogame', '13:00 - Almoço']
let pos = eventos.indexOf('11:00 - Jogar videogame')
eventos.splice(pos,1,'11:00 - Meditação')
console.log(eventos)